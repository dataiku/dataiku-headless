"""Shared helpers — eliminate duplication across commands."""

from __future__ import annotations

import contextlib
import hashlib
import json
import os
import sys
import time
from contextlib import contextmanager
from pathlib import Path
from typing import TYPE_CHECKING

import typer
from platformdirs import user_cache_dir

if TYPE_CHECKING:
    import dataikuapi

from dku_cli.client import (
    AUTH_MODE_IN_POD_TICKET,
    get_client,
    get_govern_client,
    probe_node_type,
    resolve_auth,
    resolve_node_type,
)
from dku_cli.config import get_default_project, get_profile_config
from dku_cli.enums import EvalFlavor

# Node types that support project-scoped commands (flow, datasets, recipes…).
PROJECT_NODE_TYPES = {"DESIGN", "AUTOMATION"}

# ---------------------------------------------------------------------------
# Concurrent-write protection for settings mutations
#
# DSS settings saves are unconditional full-document PUTs — the server does
# no version check, so two concurrent get→mutate→save commands on the same
# object silently drop one side's changes (lost update). Agent tool-callers
# fire mutations of one object in parallel routinely (e.g. add-step +
# add-trigger + add-reporter on a fresh scenario in one turn), and each
# command reports success because it only knows about its own write.
# ---------------------------------------------------------------------------

# Lazily created like CONFIG_DIR — importing must never crash on a read-only
# cache dir. Tests monkeypatch this to a tmp_path.
LOCK_DIR = Path(user_cache_dir("dku", ensure_exists=False)) / "locks"

_LOCK_TIMEOUT_S = 60.0
_LOCK_POLL_S = 0.2
_LOCK_DOCUMENT_TYPES = {"agent": "saved-model"}

if os.name == "nt":
    import msvcrt

    def _try_lock(fd: int) -> None:
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_NBLCK, 1)

    def _unlock(fd: int) -> None:
        os.lseek(fd, 0, os.SEEK_SET)
        msvcrt.locking(fd, msvcrt.LK_UNLCK, 1)

else:
    import fcntl

    def _try_lock(fd: int) -> None:
        fcntl.flock(fd, fcntl.LOCK_EX | fcntl.LOCK_NB)

    def _unlock(fd: int) -> None:
        fcntl.flock(fd, fcntl.LOCK_UN)


@contextmanager
def object_write_lock(
    client,
    project_key: str,
    obj_type: str,
    obj_id: str,
    *,
    timeout_s: float | None = None,
):
    """Serialize read-modify-write sections on one DSS object across dku processes.

    Advisory per-object file lock keyed by (host, project, type, id): concurrent
    same-host writers queue instead of clobbering each other, and each later
    writer re-reads the previous one's save. Released automatically if the
    process dies. Waiting more than ``timeout_s`` exits loudly. Most commands
    hold the lock only for one read-mutate-save window; longer-running call
    sites must pass a larger timeout explicitly.
    """
    from dku_cli.errors import exit_with_error

    resolved_timeout_s = _LOCK_TIMEOUT_S if timeout_s is None else timeout_s
    document_type = _LOCK_DOCUMENT_TYPES.get(obj_type, obj_type)
    key = f"{client.host}|{project_key}|{document_type}|{obj_id}"
    LOCK_DIR.mkdir(parents=True, exist_ok=True)
    path = LOCK_DIR / f"{hashlib.sha256(key.encode()).hexdigest()[:24]}.lock"
    fd = os.open(path, os.O_RDWR | os.O_CREAT, 0o644)
    try:
        deadline = time.monotonic() + resolved_timeout_s
        while True:
            try:
                _try_lock(fd)
                break
            except OSError:
                if time.monotonic() >= deadline:
                    exit_with_error(
                        f"Timed out after {resolved_timeout_s:g}s waiting for another "
                        f"dku process editing {obj_type} '{obj_id}'.",
                        details=[
                            "Another dku command holds the write lock on this object.",
                            "Re-run this command once it finishes.",
                        ],
                    )
                time.sleep(_LOCK_POLL_S)
        yield
    finally:
        # Unlock can only fail if we never acquired (timeout exit path);
        # flock/msvcrt locks are also dropped on close.
        with contextlib.suppress(OSError):
            _unlock(fd)
        os.close(fd)


def _version_number(settings) -> int | None:
    """Server-side version of a settings document, when DSS exposes one.

    dataikuapi settings classes are heterogeneous: not all have get_raw()
    (e.g. PrepareRecipeSettings), and not all documents carry a versionTag.
    Those objects get lock-only protection, no conflict probe.
    """
    get_raw = getattr(settings, "get_raw", None)
    if get_raw is None:
        return None
    raw = get_raw()
    if not isinstance(raw, dict):
        return None
    version = (raw.get("versionTag") or {}).get("versionNumber")
    return version if isinstance(version, int) else None


@contextmanager
def locked_settings(
    client,
    project_key: str,
    obj_type: str,
    obj_id: str,
    fetch,
    *,
    timeout_s: float | None = None,
):
    """Context-manager form of mutate_settings for inline mutations.

    Yields freshly fetched settings with the per-object write lock held for
    the whole read-modify-write section, and saves on exit. The versionTag
    is re-checked just before the save as a best-effort stale-document probe:
    if another writer saved after this command fetched the settings and before
    the probe, this command exits loudly instead of knowingly PUT-ing that
    stale snapshot. This is not a conditional save and does not guarantee full
    cross-host serialization. Use mutate_settings when the mutation can be
    re-applied to a fresh copy. An exception inside the block skips the save.
    """
    from dku_cli.errors import exit_with_error

    with object_write_lock(client, project_key, obj_type, obj_id, timeout_s=timeout_s):
        settings = fetch()
        version = _version_number(settings)
        yield settings
        if version is not None and _version_number(fetch()) != version:
            exit_with_error(
                f"Not saving {obj_type} '{obj_id}': another process modified it "
                "after this command fetched the settings.",
                details=["Re-run this command."],
            )
        settings.save()


def mutate_settings(
    client,
    project_key: str,
    obj_type: str,
    obj_id: str,
    *,
    fetch,
    mutate,
    max_attempts: int = 3,
    timeout_s: float | None = None,
):
    """Run fetch() → mutate(settings) → settings.save() safely under concurrency.

    Holds the per-object write lock for the whole read-modify-write section
    (serializes same-host writers), and re-checks the document's versionTag
    just before saving as a best-effort stale-document probe. The save itself
    remains an unconditional PUT, so this is not full cross-host conflict
    protection. On a detected stale fetch the mutation is re-applied to a
    freshly fetched document instead of saving the stale one over it, so
    ``mutate`` must be safe to re-run on a fresh copy. Returns whatever
    ``mutate`` returns; exits loudly if the probe keeps finding intervening
    writes.
    """
    from dku_cli.errors import exit_with_error

    with object_write_lock(client, project_key, obj_type, obj_id, timeout_s=timeout_s):
        for _ in range(max_attempts):
            settings = fetch()
            version = _version_number(settings)
            result = mutate(settings)
            if version is not None and _version_number(fetch()) != version:
                continue
            settings.save()
            return result
        exit_with_error(
            f"Could not save {obj_type} '{obj_id}': another process kept "
            f"modifying it concurrently ({max_attempts} attempts).",
            details=[
                "Re-run this command.",
                "Run mutations of the same object sequentially, not in parallel.",
            ],
        )


def _has_auth_overrides(opts: dict) -> bool:
    """Whether the command is targeting auth that may differ from stored profile metadata."""
    return bool(
        opts.get("url")
        or opts.get("api_key")
        or os.environ.get("DKU_URL")
        or os.environ.get("DKU_API_KEY")
    )


def _resolve_target_node_type(opts: dict) -> str | None:
    """Resolve node type for the actual auth target, not just stored profile metadata."""
    profile = opts.get("profile")
    if not _has_auth_overrides(opts):
        return resolve_node_type(profile=profile)

    # Ticket-mode profiles can't be probed via API-key Basic auth; trust their
    # stored node_type (init scripts that write ticket-mode profiles always
    # also set node_type explicitly).
    active = profile or os.environ.get("DKU_PROFILE")
    if (
        active
        and get_profile_config(active).get("auth_mode") == AUTH_MODE_IN_POD_TICKET
    ):
        return resolve_node_type(profile=profile)

    try:
        resolved_url, resolved_key = resolve_auth(
            url=opts.get("url"),
            api_key=opts.get("api_key"),
            profile=profile,
        )
    except Exception:
        return None

    probed = probe_node_type(resolved_url, resolved_key)
    if probed is not None:
        return probed
    return resolve_node_type(profile=profile)


def require_node_type(
    ctx: typer.Context | None,
    allowed: set[str],
    command_hint: str | None = None,
) -> None:
    """Refuse the command if the active profile is the wrong DSS node type.

    Emits a prescriptive error and exits non-zero when the profile's node type
    is known and not in ``allowed``. If the node type is unknown (legacy profile
    pre node-type tracking) we let the command proceed — the underlying API
    will still 404 but that is no worse than today.

    Args:
        ctx: Typer context — used to resolve the active profile.
        allowed: Uppercase node types accepted by the caller
            (e.g. ``{"DESIGN", "AUTOMATION"}`` or ``{"GOVERN"}``).
        command_hint: Optional alternate command to suggest
            (e.g. ``"dku govern artifact list"`` for Govern nodes).
    """
    opts = (ctx.obj if ctx is not None else {}) or {}
    nt = _resolve_target_node_type(opts)
    if nt is None or nt in allowed:
        return

    from dku_cli.errors import exit_with_error

    nice_allowed = ", ".join(sorted(allowed))
    details: list[str] = [
        f"Active profile node type: {nt}",
        f"This command requires: {nice_allowed}",
    ]
    if nt == "GOVERN":
        details.append("")
        details.append(
            "Govern nodes do not have projects, datasets, recipes, or flows."
        )
        details.append("Use the dedicated governance surface instead:")
        details.append(f"  {command_hint}" if command_hint else "  dku govern --help")
        details.append("")
        details.append("Or switch profile with: dku auth switch <design-profile>")
    else:
        details.append("")
        details.append(
            f"Switch profile with: dku auth switch <profile-on-{nice_allowed.lower()}-node>"
        )
        if command_hint:
            details.append(f"Or try: {command_hint}")

    exit_with_error(
        f"Command not available on {nt} nodes.",
        details=details,
        status=4,
    )


def resolve_project(project: str | None, ctx: typer.Context | None = None) -> str:
    """Resolve project key: --project flag > DKU_PROJECT env > config default.

    Also enforces the node-type guard: project-scoped commands require a
    DESIGN or AUTOMATION node. Passing ``ctx`` lets the guard read the
    active profile; legacy callers that omit ``ctx`` still get the env/flag
    resolution (backwards compatible).

    Raises typer.BadParameter if nothing found.
    """
    # Node-type guard runs before the project lookup so agents see the real
    # problem ("wrong node type") instead of a spurious "no project set".
    if ctx is not None:
        require_node_type(ctx, PROJECT_NODE_TYPES)

    if project:
        return project
    env_proj = os.environ.get("DKU_PROJECT")
    if env_proj:
        return env_proj
    cfg_proj = get_default_project()
    if cfg_proj:
        return cfg_proj
    raise typer.BadParameter(
        "No project specified. Use --project, DKU_PROJECT env var, or set a default."
    )


_CLIENT_OPTS = ("url", "api_key", "profile")


def get_client_from_ctx(
    ctx: typer.Context,
    *,
    allowed_node_types: set[str] | None = None,
) -> dataikuapi.DSSClient:
    """Extract global opts from ctx.obj and return authenticated DSSClient.

    By default refuses GOVERN nodes with a prescriptive error — GOVERN has no
    projects, datasets, or recipes and a raw 404 from the API tells agents
    nothing useful. Cross-node commands (whoami, user, group, admin/logs)
    opt into broader node support via ``allowed_node_types``.

    Args:
        ctx: Typer context — provides global opts (url, api_key, profile).
        allowed_node_types: Override the default (``PROJECT_NODE_TYPES``).
            Pass ``None`` or ``{"DESIGN","AUTOMATION","GOVERN","DEPLOYER","API"}``
            for commands that work on every node type. Pass a narrower set
            (e.g. ``{"DESIGN","AUTOMATION"}``) to restrict further.

    Filters to the keys `get_client()` accepts so non-auth globals
    (e.g. `dangerous`) in ctx.obj don't crash the client constructor.
    """
    if allowed_node_types is None:
        allowed_node_types = PROJECT_NODE_TYPES
    require_node_type(ctx, allowed_node_types)
    opts = ctx.obj or {}
    return get_client(**{k: opts[k] for k in _CLIENT_OPTS if k in opts})


# Commands that work on every DSS node type (whoami, admin instance-info, etc).
ALL_NODE_TYPES = {"DESIGN", "AUTOMATION", "GOVERN", "DEPLOYER", "API"}


# UI link formats — the two routes disagree and a hand-guessed link 404s:
# the dashboard route requires the trailing slash after
# /view (name slug optional); the insight route requires the "_" after the id
# and rejects a trailing slash. DSS canonicalizes the slug on load.
def dashboard_url(client, project_key: str, dashboard_id: str) -> str:
    base = client.host.rstrip("/")
    return f"{base}/projects/{project_key}/dashboards/{dashboard_id}/view/"


def insight_url(client, project_key: str, insight_id: str) -> str:
    return (
        f"{client.host.rstrip('/')}/projects/{project_key}"
        f"/dashboards/insights/{insight_id}_/view"
    )


def get_govern_client_from_ctx(ctx: typer.Context):
    """Extract global opts from ctx.obj and return authenticated GovernClient.

    Also enforces that the active profile is a GOVERN node — commands under
    ``dku govern`` only make sense against a Govern node.
    """
    require_node_type(ctx, {"GOVERN"})
    opts = ctx.obj or {}
    return get_govern_client(**{k: opts[k] for k in _CLIENT_OPTS if k in opts})


def _dict_id(item) -> str:
    return item.get("id", "")


def _dict_name(item) -> str:
    return item.get("name", "")


def _attr_id(item) -> str:
    return item.id


def _attr_name(item) -> str:
    return getattr(item, "name", "")


def _resolve_named(
    project,
    ref: str,
    *,
    get,
    list_,
    kind: str,
    empty_details: list[str],
    verify=lambda handle: None,
    id_of=_dict_id,
    name_of=_dict_name,
    list_label: str | None = None,
    id_label: str | None = None,
):
    """Resolve a named DSS object by ID first, then by name.

    Tries ``get(ref)`` (by ID) and forces existence with ``verify``. On a
    not-found error, lists via ``list_`` and matches on ``name_of``, re-fetching
    the matched item's id through ``get``. Aborts via ``exit_with_error`` with a
    prescriptive message when neither path resolves.
    """
    import dataikuapi

    from dku_cli.errors import exit_with_error, is_not_found_error

    try:
        handle = get(ref)
        verify(handle)
        return handle
    except dataikuapi.utils.DataikuException as e:
        if not is_not_found_error(e):
            raise
    items = list(list_())
    for item in items:
        if name_of(item) == ref:
            return get(id_of(item))

    plural = list_label or f"{kind.lower()}s"
    singular = id_label or kind.lower()
    listed = [f"  {id_of(item)} ({name_of(item)})" for item in items]
    exit_with_error(
        f"{kind} '{ref}' not found (checked as both ID and name).",
        details=[
            f"Available {plural}:",
            *listed,
            f"Use the {singular} ID (left column) or exact name.",
        ]
        if listed
        else empty_details,
        status=3,
    )


def resolve_agent(project, agent_ref: str):
    """Resolve an agent by ID or name.

    Tries get_agent(ref) first (by ID). If that raises NotFoundException,
    falls back to listing agents and matching by name.
    Returns a DSSAgent handle.
    """
    return _resolve_named(
        project,
        agent_ref,
        get=project.get_agent,
        verify=lambda h: h.get_settings(),
        list_=project.list_agents,
        kind="Agent",
        empty_details=[
            "No agents found in this project.",
            "Create one with: dku agent create NAME -P PROJECT",
        ],
    )


def resolve_knowledge_bank(project, kb_ref: str):
    """Resolve a knowledge bank by ID or name.

    Tries get_knowledge_bank(ref) first (by ID). If that raises NotFoundException,
    falls back to listing knowledge banks and matching by name.
    Returns a DSSKnowledgeBank handle.
    """
    return _resolve_named(
        project,
        kb_ref,
        get=project.get_knowledge_bank,
        verify=lambda h: h.get_settings(),
        list_=project.list_knowledge_banks,
        kind="Knowledge bank",
        empty_details=[
            "No knowledge banks found in this project.",
            "Create one with: dku knowledge create NAME --embedding-llm LLM_ID -P PROJECT",
        ],
    )


def probe_knowledge_bank(kb, query: str = "test") -> tuple[int | None, str | None]:
    """Probe a knowledge bank with a minimal search to confirm queryable content.

    A KB build job reporting DONE only means the job ran — it does not guarantee
    any document was embedded and indexed. The only ground-truth signal DSS
    exposes is a live search: an empty/unindexed KB returns zero documents.

    Returns (doc_count, None) on a successful probe (0 = built but empty), or
    (None, error_message) if the search itself failed.
    """
    try:
        result = kb.search(query, max_documents=1)
    except Exception as e:
        return None, str(e)
    docs = getattr(result, "documents", result)
    return (len(docs) if docs is not None else 0), None


def resolve_semantic_model(project, sm_ref: str):
    """Resolve a semantic model by ID or name.

    Tries get_semantic_model(ref) first (by ID). If that raises NotFoundException,
    falls back to listing semantic models and matching by name.
    Returns a DSSSemanticModel handle.
    """
    return _resolve_named(
        project,
        sm_ref,
        get=project.get_semantic_model,
        verify=lambda h: h._get_definition(),
        list_=project.list_semantic_models,
        kind="Semantic model",
        empty_details=[
            "No semantic models found in this project.",
            "Create one with: dku semantic-model create NAME -P PROJECT",
        ],
    )


def resolve_agent_review(project, review_ref: str):
    """Resolve an agent review by ID or name.

    Tries get_agent_review(ref) first (by ID). If that raises NotFoundException,
    falls back to listing reviews and matching by name.
    Returns a DSSAgentReview handle.
    """
    from dku_cli.errors import exit_with_error

    # An empty ref hits GET /agent-reviews/reviews/ (the list endpoint) and
    # returns the whole list wrapped as a single review — later .id access then
    # crashes with "'list' object has no attribute 'get'". Fail loudly instead.
    # Empty refs come from a prior `create` whose id wasn't captured. (This is a
    # distinct symptom from "Invalid loc: empty name", which has a *valid* ref
    # but no agent bound to the review — that's handled in run_review.)
    if not review_ref or not str(review_ref).strip():
        exit_with_error(
            "Agent review id/name is empty.",
            details=[
                "A previous `dku agent-review create` likely did not return an id.",
                "List reviews to get a valid id: dku agent-review list -P PROJECT",
                'create prints {"id": ...} on stdout — capture it with '
                "ID=$(dku agent-review create NAME -P PROJECT | jq -r .id).",
            ],
            status=3,
        )

    return _resolve_named(
        project,
        review_ref,
        get=project.get_agent_review,
        list_=project.list_agent_reviews,
        kind="Agent review",
        id_of=_attr_id,
        name_of=_attr_name,
        id_label="review",
        empty_details=[
            "No agent reviews found in this project.",
            "Create one with: dku agent-review create NAME -P PROJECT",
        ],
    )


def resolve_folder(project, folder_ref: str):
    """Resolve a managed folder by ID or name.

    Tries get_managed_folder(ref) first (by ID). If that raises NotFoundException,
    falls back to listing managed folders and matching by name.
    Returns a DSSManagedFolder handle.
    """
    return _resolve_named(
        project,
        folder_ref,
        get=project.get_managed_folder,
        verify=lambda h: h.get_settings(),
        list_=project.list_managed_folders,
        kind="Managed folder",
        id_label="folder",
        empty_details=[
            "No managed folders found in this project.",
            "Create one with: dku folder create NAME -P PROJECT",
        ],
    )


def resolve_saved_model(project, model_ref: str):
    """Resolve a saved model by ID or name.

    Tries get_saved_model(ref).get_settings() first (by ID). If that raises,
    falls back to listing saved models and matching by name.
    Returns a DSSSavedModel handle.
    """
    return _resolve_named(
        project,
        model_ref,
        get=project.get_saved_model,
        verify=lambda h: h.get_settings(),
        list_=project.list_saved_models,
        kind="Saved model",
        empty_details=[
            "No saved models found in this project.",
            "Train one with: dku ml create-prediction / create-clustering + train + deploy.",
        ],
    )


def resolve_build_output_types(project, refs):
    """Map build output refs to (resolved_ref, object_type) for the job builder.

    Recipe outputs (``get_flat_output_refs()``) and ``dku job run --target`` give
    bare refs. ``JobDefinitionBuilder.with_output`` defaults ``object_type`` to
    DATASET server-side, so managed-folder / saved-model / knowledge-bank /
    evaluation-store outputs error with "dataset <id> does not exist". Classify
    each ref by checking the project's folders, saved models, knowledge banks
    and evaluation stores once, resolving names to IDs where needed.

    Cross-project refs ("PROJECT.id") are left as-is and treated as DATASET
    (recipe outputs are always local; cross-project build targets are uncommon
    and DATASET is the safe default).

    :returns: list of (resolved_ref, object_type) tuples, one per input ref.
    """
    # Folders + saved models are cheap single list calls and are needed to tell
    # a dataset apart from them, so classify against those first (preserving the
    # original folder → saved-model precedence). A ref confirmed to be a plain
    # dataset then short-circuits to DATASET, so the two expensive lookups
    # (knowledge banks + evaluation stores) are deferred and never issued on the
    # hot path where every output is a folder/model/dataset (e.g.
    # `dku job run --target my_dataset`). Resolution precedence is unchanged:
    # folders → saved models → knowledge banks → evaluation stores → DATASET
    # (datasets, KBs and eval stores live in disjoint namespaces, so the
    # dataset short-circuit cannot steal a ref that would have been a KB/MES).
    folders = project.list_managed_folders()
    models = project.list_saved_models()
    folder_ids = {f.get("id") for f in folders}
    folder_by_name = {f.get("name"): f.get("id") for f in folders if f.get("name")}
    model_ids = {m.get("id") for m in models}
    model_by_name = {m.get("name"): m.get("id") for m in models if m.get("name")}

    _deferred: dict[str, tuple[set, dict]] = {}

    def _datasets() -> tuple[set, dict]:
        # Cheap single list call used only to short-circuit a known dataset to
        # DATASET before paying the KB/eval-store round-trips. Tolerate older
        # DSS / failures by treating the project as having no listable datasets,
        # which falls through to the KB → MES → DATASET path (original behavior).
        if "ds" not in _deferred:
            try:
                datasets = project.list_datasets()
                ids = {d.get("name") for d in datasets if d.get("name")}
            except Exception:
                ids = set()
            _deferred["ds"] = (ids, {})
        return _deferred["ds"]

    def _kbs() -> tuple[set, dict]:
        # Knowledge banks build as RETRIEVABLE_KNOWLEDGE — the exact type
        # DSSKnowledgeBank.build() posts. Without this, embed recipe outputs
        # fall through to DATASET and the job fails with the misleading
        # "dataset <id> does not exist". The endpoint may be absent on older
        # DSS — treat lookup failures as "project has none".
        if "kb" not in _deferred:
            try:
                kbs = project.list_knowledge_banks()  # listitems extend dict
                ids = {kb.get("id") for kb in kbs}
                by_name = {kb.get("name"): kb.get("id") for kb in kbs if kb.get("name")}
            except Exception:
                ids, by_name = set(), {}
            _deferred["kb"] = (ids, by_name)
        return _deferred["kb"]

    def _stores() -> tuple[set, dict]:
        # Evaluation stores build as MODEL_EVALUATION_STORE — the type
        # DSSEvaluationStore.build() posts; same DATASET-fallthrough hazard as
        # knowledge banks. Quirk: public list_evaluation_stores() returns
        # handles whose names need one get_settings() call each (N+1); the raw
        # fetch returns {id, name, mesFlavor} dicts in a single call. The
        # endpoint may be absent on older DSS — tolerate failures.
        if "mes" not in _deferred:
            try:
                stores = []
                for flavor in EvalFlavor:
                    stores.extend(project._fetch_evaluation_stores(flavor=str(flavor)))
                ids = {s.get("id") for s in stores}
                by_name = {s.get("name"): s.get("id") for s in stores if s.get("name")}
            except Exception:
                ids, by_name = set(), {}
            _deferred["mes"] = (ids, by_name)
        return _deferred["mes"]

    resolved: list[tuple[str, str]] = []
    for ref in refs:
        if ref in folder_ids:
            resolved.append((ref, "MANAGED_FOLDER"))
            continue
        if ref in folder_by_name:
            resolved.append((folder_by_name[ref], "MANAGED_FOLDER"))
            continue
        if ref in model_ids:
            resolved.append((ref, "SAVED_MODEL"))
            continue
        if ref in model_by_name:
            resolved.append((model_by_name[ref], "SAVED_MODEL"))
            continue
        ds_ids, _ = _datasets()
        if ref in ds_ids:
            # Known dataset — short-circuit before the expensive KB/MES probes.
            resolved.append((ref, "DATASET"))
            continue
        kb_ids, kb_by_name = _kbs()
        if ref in kb_ids:
            resolved.append((ref, "RETRIEVABLE_KNOWLEDGE"))
            continue
        if ref in kb_by_name:
            resolved.append((kb_by_name[ref], "RETRIEVABLE_KNOWLEDGE"))
            continue
        mes_ids, mes_by_name = _stores()
        if ref in mes_ids:
            resolved.append((ref, "MODEL_EVALUATION_STORE"))
            continue
        if ref in mes_by_name:
            resolved.append((mes_by_name[ref], "MODEL_EVALUATION_STORE"))
            continue
        resolved.append((ref, "DATASET"))
    return resolved


def resolve_recipe_input_ref(project, ref: str, explicit_type: str | None = None):
    """Resolve a recipe input ref to (kind, resolved_ref) where kind is one of
    "DATASET", "MANAGED_FOLDER", "SAVED_MODEL".

    If explicit_type is given, only that kind is tried (and resolution failure
    aborts via exit_with_error with prescriptive guidance).

    With no explicit_type, tries dataset → folder → saved model in order and
    returns the first match. If more than one kind matches, aborts with an
    ambiguity error so the caller can disambiguate via --type.
    """
    import dataikuapi

    from dku_cli.errors import exit_with_error, is_not_found_error

    kind = (explicit_type or "").upper() or None

    def _try_dataset():
        # Dataset names are the canonical dataset ref — no ID/name distinction.
        try:
            project.get_dataset(ref).get_definition()
            return ref
        except dataikuapi.utils.DataikuException as e:
            if is_not_found_error(e):
                return None
            raise

    def _try_folder():
        # Use list-match — folders have distinct ID/name; get_managed_folder is
        # lazy and get_settings() doesn't reliably raise on MagicMocks/tests.
        for f in project.list_managed_folders():
            if f.get("id") == ref or f.get("name", "") == ref:
                return f.get("id")
        return None

    def _try_model():
        for m in project.list_saved_models():
            if m.get("id") == ref or m.get("name", "") == ref:
                return m.get("id")
        return None

    if kind == "DATASET":
        resolved = _try_dataset()
        if resolved is None:
            exit_with_error(
                f"Dataset '{ref}' not found in this project.",
                details=[
                    "List datasets: dku dataset list -P PROJ",
                    "If this is a folder, pass --type MANAGED_FOLDER.",
                    "If this is a saved model, pass --type SAVED_MODEL.",
                ],
                status=3,
            )
        return "DATASET", resolved
    if kind == "MANAGED_FOLDER":
        resolved = _try_folder()
        if resolved is None:
            exit_with_error(
                f"Managed folder '{ref}' not found in this project.",
                details=["List folders: dku folder list -P PROJ"],
                status=3,
            )
        return "MANAGED_FOLDER", resolved
    if kind == "SAVED_MODEL":
        resolved = _try_model()
        if resolved is None:
            exit_with_error(
                f"Saved model '{ref}' not found in this project.",
                details=["List saved models: dku ml models -P PROJ"],
                status=3,
            )
        return "SAVED_MODEL", resolved

    # Auto-detect
    matches = []
    ds = _try_dataset()
    if ds is not None:
        matches.append(("DATASET", ds))
    fd = _try_folder()
    if fd is not None:
        matches.append(("MANAGED_FOLDER", fd))
    sm = _try_model()
    if sm is not None:
        matches.append(("SAVED_MODEL", sm))

    if not matches:
        exit_with_error(
            f"'{ref}' is not a dataset, managed folder, or saved model in this project.",
            details=[
                "List candidates:",
                "  dku dataset list -P PROJ",
                "  dku folder list -P PROJ",
                "  dku ml models -P PROJ",
                "Folders and saved models must be referenced by their ID (or unique name).",
            ],
            status=3,
        )
    if len(matches) > 1:
        exit_with_error(
            f"'{ref}' is ambiguous — matches multiple object types: "
            f"{', '.join(k for k, _ in matches)}.",
            details=[
                "Disambiguate with --type DATASET|MANAGED_FOLDER|SAVED_MODEL.",
            ],
            status=3,
        )
    return matches[0]


def update_taggable_metadata(
    settings,
    description: str | None = None,
    short_desc: str | None = None,
    tags: str | None = None,
) -> None:
    """Update description/short_desc/tags on a DSSTaggableObjectSettings and save.

    Works with Dashboard, Insight, SavedModel, and Agent settings objects
    that extend DSSTaggableObjectSettings.

    Args:
        settings: A DSSTaggableObjectSettings-based settings object with save().
        description: Long description text, or None to leave unchanged.
        short_desc: Short description text, or None to leave unchanged.
        tags: Comma-separated tag string, or None to leave unchanged.
    """
    if description is not None:
        settings.description = description
    if short_desc is not None:
        settings.short_description = short_desc
    if tags is not None:
        settings.tags = [t.strip() for t in tags.split(",") if t.strip()]
    settings.save()


def read_text_input(value: str) -> str:
    """Read text from: raw string, @file.txt path, or stdin if value is '-'.

    Same pattern as set-code but reusable for any text input (prompts, etc.).
    Raises typer.BadParameter on file-not-found.
    """
    if value == "-":
        return sys.stdin.read()
    if value.startswith("@"):
        path = Path(value[1:])
        if not path.exists():
            raise typer.BadParameter(f"File not found: {path}")
        return path.read_text()
    return value


def clean_llm_id(value: str) -> tuple[str, bool]:
    """Strip stray surrounding quote characters from an LLM id.

    Agents repeatedly mis-quote `--llm` (e.g. `--llm '"'openai:...` reaches the
    process as `"openai:...`), then loop trying to fix the quoting. LLM ids are
    `provider:service:model` and never contain quotes, so leading/trailing `"`/`'`
    are always spurious. Returns (cleaned, was_changed) so the caller can warn.
    """
    cleaned = value.strip("\"'")
    return cleaned, cleaned != value


def read_json_input(value: str | None) -> dict | list | None:
    """Parse JSON from: raw string, @file.json path, or stdin if value is '-'.

    Returns None if value is None.
    Raises typer.BadParameter on invalid JSON (clean error for agents/scripts).
    """
    if value is None:
        return None
    try:
        if value == "-":
            return json.load(sys.stdin)
        if value.startswith("@"):
            path = Path(value[1:])
            if not path.exists():
                raise typer.BadParameter(f"File not found: {path}")
            return json.loads(path.read_text())
        return json.loads(value)
    except json.JSONDecodeError as exc:
        source = (
            "stdin"
            if value == "-"
            else f"'{value[:80]}...'"
            if len(value) > 80
            else f"'{value}'"
        )
        raise typer.BadParameter(f"Invalid JSON from {source}: {exc}") from exc


def unpersisted_key_paths(sent: dict, persisted: dict) -> list[str]:
    """Dotted paths of dict keys present in *sent* but absent after a save.

    DSS deserializes typed settings (dataset definitions, project settings)
    into fixed-shape objects and SILENTLY DROPS unknown or misplaced keys —
    exit 0, success message, key gone. Comparing the user's payload against a
    re-read of the saved object turns that silent no-op into a same-turn
    warning at the exact point of failure.

    Only dict nesting is walked; list contents are not compared (DSS reorders
    and normalizes list items, which would false-positive). A key whose VALUE
    was normalized still exists and is not reported.

    Note: only useful for typed-settings objects. Recipe payloads and agent
    tool params are stored as opaque JSON and persist unknown keys verbatim —
    a round-trip diff can never fire there, so don't wire it in.
    """
    dropped: list[str] = []

    def _walk(sent_node: dict, persisted_node: dict, prefix: str) -> None:
        for key, value in sent_node.items():
            path = f"{prefix}.{key}" if prefix else str(key)
            if key not in persisted_node:
                dropped.append(path)
                continue
            if isinstance(value, dict) and isinstance(persisted_node.get(key), dict):
                _walk(value, persisted_node[key], path)

    _walk(sent, persisted, "")
    return dropped
